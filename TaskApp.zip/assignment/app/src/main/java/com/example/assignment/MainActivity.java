package com.example.assignment;// MainActivity.java

import androidx.recyclerview.widget.RecyclerView;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {

    private List<Task> tasks = new ArrayList<>();
    private TaskAdapter taskAdapter;
    private TaskExecutionThread taskExecutionThread;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize RecyclerView
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        taskAdapter = new TaskAdapter(tasks);
        recyclerView.setAdapter(taskAdapter);

        // Initialize task entry components
        EditText editTextTaskName = findViewById(R.id.editTextTaskName);
        Spinner spinnerPriority = findViewById(R.id.spinnerPriority);
        Button buttonAddTask = findViewById(R.id.buttonAddTask);
        Button buttonExecuteTasks = findViewById(R.id.buttonExecuteTasks);

        // Set up spinner with priority options
        String[] priorityOptions = {"1", "2", "3", "4", "5"};
        ArrayAdapter<String> priorityAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, priorityOptions);
        spinnerPriority.setAdapter(priorityAdapter);

        // Set up click listener for adding tasks
        buttonAddTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addTask(editTextTaskName.getText().toString(), Integer.parseInt(spinnerPriority.getSelectedItem().toString()));
                updateTaskList();
                clearTaskEntry();
            }
        });

        // Set up click listener for executing tasks
        buttonExecuteTasks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                executeTasks();
            }
        });
    }

    private void addTask(String name, int priority) {
        Task task = new Task(name, priority);
        tasks.add(task);
        // Sort tasks based on priority
        tasks.sort((task1, task2) -> Integer.compare(task1.getPriority(), task2.getPriority()));
    }

    private void updateTaskList() {
        taskAdapter.notifyDataSetChanged();
    }

    private void clearTaskEntry() {
        EditText editTextTaskName = findViewById(R.id.editTextTaskName);
        Spinner spinnerPriority = findViewById(R.id.spinnerPriority);
        editTextTaskName.getText().clear();
        spinnerPriority.setSelection(0);
    }

    private void executeTasks() {
        taskExecutionThread = new TaskExecutionThread(tasks, this);
        taskExecutionThread.start();
    }
}
