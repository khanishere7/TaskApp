// TaskExecutionThread.java
package com.example.assignment;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.util.List;

public class TaskExecutionThread extends Thread {
    private static final String TAG = "TaskExecutionThread";

    private List<Task> tasks;
    private Context context;
    private Handler handler;
    private NotificationScheduler notificationScheduler;

    public TaskExecutionThread(List<Task> tasks, Context context) {
        this.tasks = tasks;
        this.context = context;
        this.handler = new Handler(Looper.getMainLooper());
        this.notificationScheduler = new NotificationScheduler(context);
    }

    @Override
    public void run() {
        for (Task task : tasks) {
            executeTask(task);
        }
    }

    private void executeTask(Task task) {
        try {
            // Simulate task execution delay
            Thread.sleep(task.getPriority() * 1000);
            showNotification(task);
        } catch (InterruptedException e) {
            Log.e(TAG, "Task execution interrupted: " + e.getMessage());
        }
    }

    private void showNotification(final Task task) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                Log.d(TAG, "Executing task: " + task.getName());
                notificationScheduler.scheduleNotification(task.getName());
            }
        });
    }
}
