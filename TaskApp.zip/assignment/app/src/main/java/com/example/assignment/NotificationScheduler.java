// NotificationScheduler.java
package com.example.assignment;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;

import androidx.core.app.NotificationCompat;

public class NotificationScheduler {
    private static final long DEFAULT_DELAY = 5000; // 5 seconds delay (adjust as needed)
    private static final String CHANNEL_ID = "task_channel";
    private final Context context;

    public NotificationScheduler(Context context) {
        this.context = context;
        createNotificationChannel();
    }

    public void scheduleNotification(String taskName, long delay) {
        new android.os.Handler().postDelayed(
                () -> showNotification(taskName),
                delay);
    }

    // Overloaded method for using the default delay
    public void scheduleNotification(String taskName) {
        scheduleNotification(taskName, DEFAULT_DELAY);
    }

    private void showNotification(String taskName) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("Task Reminder")
                .setContentText("It's time to do: " + taskName)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.notify(getNotificationId(), builder.build());
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Task Channel";
            String description = "Channel for task notifications";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);

            NotificationManager notificationManager = context.getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    private int getNotificationId() {
        // You can generate a unique notification ID based on your requirements
        return (int) System.currentTimeMillis();
    }
}
